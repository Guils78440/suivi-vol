package fr.guillaume.suivivol

import android.location.Location
import android.os.Build
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/** Calculs géographiques : distances, caps, orthodromie, projection Mercator, formatage. */
object GeoMath {
    const val R_EARTH_KM = 6371.0088
    private const val MAX_LAT = 85.05112878

    fun distanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val p1 = Math.toRadians(lat1)
        val p2 = Math.toRadians(lat2)
        val dp = p2 - p1
        val dl = Math.toRadians(lon2 - lon1)
        val a = sin(dp / 2).pow(2) + cos(p1) * cos(p2) * sin(dl / 2).pow(2)
        return 2 * R_EARTH_KM * asin(min(1.0, sqrt(a)))
    }

    fun bearingDeg(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val p1 = Math.toRadians(lat1)
        val p2 = Math.toRadians(lat2)
        val dl = Math.toRadians(lon2 - lon1)
        val y = sin(dl) * cos(p2)
        val x = cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl)
        return (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0
    }

    /**
     * Route orthodromique (la vraie trajectoire la plus courte d'un avion).
     * Renvoie des paires [lat, lon] avec longitudes "déroulées" (peuvent dépasser ±180)
     * pour que le tracé reste continu au passage de l'antiméridien.
     */
    fun greatCircle(lat1: Double, lon1: Double, lat2: Double, lon2: Double, n: Int = 160): List<DoubleArray> {
        val d = distanceKm(lat1, lon1, lat2, lon2) / R_EARTH_KM
        if (d < 1e-9 || abs(d - PI) < 1e-6) {
            return unwrap(listOf(doubleArrayOf(lat1, lon1), doubleArrayOf(lat2, lon2)))
        }
        val p1 = Math.toRadians(lat1); val l1 = Math.toRadians(lon1)
        val p2 = Math.toRadians(lat2); val l2 = Math.toRadians(lon2)
        val sd = sin(d)
        val out = ArrayList<DoubleArray>(n + 1)
        for (i in 0..n) {
            val f = i.toDouble() / n
            val a = sin((1 - f) * d) / sd
            val b = sin(f * d) / sd
            val x = a * cos(p1) * cos(l1) + b * cos(p2) * cos(l2)
            val y = a * cos(p1) * sin(l1) + b * cos(p2) * sin(l2)
            val z = a * sin(p1) + b * sin(p2)
            out.add(doubleArrayOf(Math.toDegrees(atan2(z, sqrt(x * x + y * y))), Math.toDegrees(atan2(y, x))))
        }
        return unwrap(out)
    }

    /** Rend les longitudes continues (évite les sauts de 360° au passage de l'antiméridien). */
    fun unwrap(points: List<DoubleArray>): List<DoubleArray> {
        if (points.isEmpty()) return points
        val out = ArrayList<DoubleArray>(points.size)
        var prev = points[0][1]
        out.add(doubleArrayOf(points[0][0], prev))
        for (i in 1 until points.size) {
            var lon = points[i][1]
            while (lon - prev > 180) lon -= 360
            while (lon - prev < -180) lon += 360
            out.add(doubleArrayOf(points[i][0], lon))
            prev = lon
        }
        return out
    }

    /** Mercator normalisé : x et y dans [0,1] pour le monde entier (x peut sortir si lon déroulée). */
    fun mercX(lon: Double): Double = (lon + 180.0) / 360.0

    fun mercY(lat: Double): Double {
        val l = lat.coerceIn(-MAX_LAT, MAX_LAT)
        val s = sin(Math.toRadians(l))
        return 0.5 - ln((1 + s) / (1 - s)) / (4 * PI)
    }

    private val CARDINAUX = arrayOf(
        "N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
        "S", "SSO", "SO", "OSO", "O", "ONO", "NO", "NNO"
    )

    fun cardinal(deg: Double): String = CARDINAUX[(((deg % 360 + 360) % 360) / 22.5 + 0.5).toInt() % 16]

    /** Altitude au-dessus du niveau de la mer quand Android la fournit (Android 14+), sinon ellipsoïdale. */
    fun altitudeM(loc: Location): Double? {
        if (Build.VERSION.SDK_INT >= 34 && loc.hasMslAltitude()) return loc.mslAltitudeMeters
        return if (loc.hasAltitude()) loc.altitude else null
    }

    fun intFr(v: Double): String = String.format(Locale.FRANCE, "%,d", v.roundToInt())

    fun dureeFr(ms: Long): String {
        val totalMin = (ms / 60000L).coerceAtLeast(0)
        val h = totalMin / 60
        val m = totalMin % 60
        return if (h > 0) "$h h ${m.toString().padStart(2, '0')}" else "$m min"
    }
}
