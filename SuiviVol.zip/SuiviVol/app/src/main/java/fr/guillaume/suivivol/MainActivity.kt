package fr.guillaume.suivivol

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    // Couleurs (thème néon sombre)
    private val bg = Color.parseColor("#050B14")
    private val panel = Color.parseColor("#0B1726")
    private val cyan = Color.parseColor("#00E5FF")
    private val magenta = Color.parseColor("#FF4FD8")
    private val muted = Color.parseColor("#7F96AD")

    private lateinit var map: FlightMapView
    private lateinit var tvRoute: TextView
    private lateinit var tvRouteSub: TextView
    private lateinit var tvBanner: TextView
    private lateinit var btnFollow: TextView
    private lateinit var progress: ProgressBar
    private lateinit var tvProgress: TextView
    private lateinit var tvInfo: TextView
    private lateinit var btnStart: Button
    private val cells = HashMap<String, Pair<TextView, TextView>>()

    private val ui = Handler(Looper.getMainLooper())
    private val stateListener: () -> Unit = { map.refresh(); updateDashboard() }
    private val ticker = object : Runnable {
        override fun run() { updateDashboard(); ui.postDelayed(this, 5000) }
    }

    private var pendingStart = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupWindow()
        setContentView(buildUi())
        WorldData.load(this) {
            if (TrackingState.dep == null && TrackingState.dest == null) TrackingState.loadRoute(this)
            applyRoute(fit = true)
            updateDashboard()
        }
    }

    override fun onStart() {
        super.onStart()
        TrackingState.addListener(stateListener)
        ui.post(ticker)
        if (TrackingState.tracking) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        updateDashboard()
    }

    override fun onStop() {
        TrackingState.removeListener(stateListener)
        ui.removeCallbacks(ticker)
        super.onStop()
    }

    // ------------------------------------------------------------------ UI

    private fun setupWindow() {
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }

    private fun dp(v: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

    private fun rounded(color: Int, radiusDp: Float, strokeColor: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        if (strokeColor != null) setStroke(dp(1f), strokeColor)
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        root.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val b = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                v.setPadding(b.left, b.top, b.right, b.bottom)
            } else {
                @Suppress("DEPRECATION")
                v.setPadding(
                    insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight, insets.systemWindowInsetBottom
                )
            }
            insets
        }

        // En-tête : route (toucher pour changer le vol)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(10f), dp(16f), dp(8f))
            setOnClickListener { pickFlight() }
        }
        tvRoute = TextView(this).apply {
            setTextColor(cyan); textSize = 22f; typeface = Typeface.DEFAULT_BOLD
            text = "Choisir le vol ✈"
        }
        tvRouteSub = TextView(this).apply { setTextColor(muted); textSize = 13f }
        header.addView(tvRoute); header.addView(tvRouteSub)
        root.addView(header)

        // Carte + bandeau + bouton de recentrage
        val mapFrame = FrameLayout(this)
        map = FlightMapView(this)
        mapFrame.addView(map, FrameLayout.LayoutParams(-1, -1))
        tvBanner = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 13f
            setPadding(dp(12f), dp(6f), dp(12f), dp(6f))
            background = rounded(Color.parseColor("#CC0B1726"), 16f, magenta)
            visibility = View.GONE
        }
        mapFrame.addView(tvBanner, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(10f)
        })
        btnFollow = TextView(this).apply {
            text = "◎ Suivre l'avion"; setTextColor(bg); textSize = 14f; typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(14f), dp(8f), dp(14f), dp(8f))
            background = rounded(cyan, 20f)
            visibility = View.GONE
            setOnClickListener { map.setFollow(true) }
        }
        mapFrame.addView(btnFollow, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dp(12f), dp(12f))
        })
        val btnFit = TextView(this).apply {
            text = "⤢ Route"; setTextColor(Color.WHITE); textSize = 14f
            setPadding(dp(14f), dp(8f), dp(14f), dp(8f))
            background = rounded(Color.parseColor("#CC0B1726"), 20f, Color.parseColor("#2E5578"))
            setOnClickListener { map.setFollow(false); map.fitRoute() }
        }
        mapFrame.addView(btnFit, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply {
            setMargins(dp(12f), 0, 0, dp(12f))
        })
        map.onFollowChanged = { f -> btnFollow.visibility = if (f) View.GONE else View.VISIBLE }
        root.addView(mapFrame, LinearLayout.LayoutParams(-1, 0, 1f))

        // Barre d'avancement
        val progRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16f), dp(8f), dp(16f), 0)
        }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(magenta)
        }
        tvProgress = TextView(this).apply { setTextColor(muted); textSize = 12f; setPadding(dp(10f), 0, 0, 0) }
        progRow.addView(progress, LinearLayout.LayoutParams(0, -2, 1f))
        progRow.addView(tvProgress)
        root.addView(progRow)

        // Tableau de bord 3 × 2
        val grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10f), dp(6f), dp(10f), 0)
        }
        grid.addView(row("alt" to "ALTITUDE", "spd" to "VITESSE SOL", "hdg" to "CAP"))
        grid.addView(row("rem" to "RESTANT", "eta" to "ARRIVÉE", "flown" to "PARCOURU"))
        root.addView(grid)

        tvInfo = TextView(this).apply {
            setTextColor(muted); textSize = 12f
            setPadding(dp(16f), dp(6f), dp(16f), dp(4f))
        }
        root.addView(tvInfo)

        // Boutons
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(10f), dp(4f), dp(10f), dp(10f))
        }
        val btnFlight = actionButton("Vol", Color.parseColor("#13263A"), Color.WHITE) { pickFlight() }
        btnStart = actionButton("▶ Démarrer", cyan, bg) { toggleTracking() }
        val btnTraces = actionButton("Traces", Color.parseColor("#13263A"), Color.WHITE) { showTraces() }
        buttons.addView(btnFlight, LinearLayout.LayoutParams(0, dp(52f), 1f).apply { marginEnd = dp(6f) })
        buttons.addView(btnStart, LinearLayout.LayoutParams(0, dp(52f), 1.6f).apply { marginEnd = dp(6f) })
        buttons.addView(btnTraces, LinearLayout.LayoutParams(0, dp(52f), 1f))
        root.addView(buttons)
        return root
    }

    private fun actionButton(label: String, color: Int, textColor: Int, onClick: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 16f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(textColor)
        background = rounded(color, 14f)
        stateListAnimator = null
        setOnClickListener { onClick() }
    }

    private fun row(vararg items: Pair<String, String>): View {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((key, label) in items) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10f), dp(8f), dp(8f), dp(8f))
                background = rounded(panel, 12f, Color.parseColor("#14304A"))
            }
            cell.addView(TextView(this).apply {
                text = label; setTextColor(muted); textSize = 10f; letterSpacing = 0.08f
            })
            val value = TextView(this).apply {
                text = "—"; setTextColor(Color.WHITE); textSize = 20f
                typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
                maxLines = 1
            }
            val sub = TextView(this).apply { text = " "; setTextColor(cyan); textSize = 12f; maxLines = 1 }
            cell.addView(value); cell.addView(sub)
            cells[key] = value to sub
            r.addView(cell, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3f), dp(3f), dp(3f), dp(3f)) })
        }
        return r
    }

    private fun setCell(key: String, value: String, sub: String) {
        cells[key]?.let { it.first.text = value; it.second.text = sub }
    }

    // ------------------------------------------------------------- Tableau de bord

    private fun updateDashboard() {
        if (!::map.isInitialized) return
        val st = TrackingState
        val loc = st.lastLocation

        btnStart.text = if (st.tracking) "■ Terminer le vol" else "▶ Démarrer"
        btnStart.background = rounded(if (st.tracking) magenta else cyan, 14f)
        if (st.tracking) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Bandeau d'état GPS
        val age = loc?.let { (System.currentTimeMillis() - it.time) / 1000 } ?: 0
        val banner = when {
            !st.tracking -> null
            loc == null -> "Recherche GPS… ${st.satsVisible} satellites visibles"
            age > 30 -> "Signal GPS perdu depuis ${GeoMath.dureeFr(age * 1000)} — rapproche-toi du hublot"
            else -> null
        }
        tvBanner.text = banner ?: ""
        tvBanner.visibility = if (banner == null) View.GONE else View.VISIBLE

        if (loc != null) {
            val alt = GeoMath.altitudeM(loc)
            if (alt != null) setCell("alt", "${GeoMath.intFr(alt)} m", "${GeoMath.intFr(alt * 3.28084)} ft · FL${String.format(Locale.FRANCE, "%03d", (alt * 3.28084 / 100).toInt().coerceAtLeast(0))}")
            else setCell("alt", "—", " ")
            val v = st.smoothedSpeed
            if (!v.isNaN()) setCell("spd", "${GeoMath.intFr(v * 3.6)} km/h", "${GeoMath.intFr(v * 1.943844)} kt")
            val b = st.bearing
            if (!b.isNaN()) setCell("hdg", "${b.toInt()}°", GeoMath.cardinal(b))
        } else {
            setCell("alt", "—", " "); setCell("spd", "—", " "); setCell("hdg", "—", " ")
        }

        val rem = st.remainingKm()
        if (rem != null) setCell("rem", "${GeoMath.intFr(rem)} km", "${GeoMath.intFr(rem / 1.852)} NM")
        else setCell("rem", st.routeKm()?.let { "${GeoMath.intFr(it)} km" } ?: "—", if (st.routeKm() != null) "route totale" else " ")

        val remMs = st.remainingMillis()
        if (remMs != null) {
            val eta = Date(System.currentTimeMillis() + remMs)
            setCell("eta", SimpleDateFormat("HH:mm", Locale.FRANCE).format(eta), "dans ${GeoMath.dureeFr(remMs)}")
        } else setCell("eta", "—", if (st.dest == null) "choisir l'arrivée" else "en attente de vol")

        if (st.firstFixTime > 0) {
            setCell("flown", "${GeoMath.intFr(st.distanceFlownKm)} km", "depuis ${GeoMath.dureeFr(System.currentTimeMillis() - st.firstFixTime)}")
        } else setCell("flown", "—", " ")

        val p = st.progress()
        progress.progress = ((p ?: 0.0) * 1000).toInt()
        tvProgress.text = if (p != null) "${(p * 100).toInt()} % du trajet" else ""

        // Ligne d'infos : pays survolé, aéroport le plus proche, qualité GPS
        val info = ArrayList<String>()
        if (loc != null && WorldData.loaded) {
            info.add("Survol : " + (WorldData.countryAt(loc.latitude, loc.longitude) ?: "mer / océan"))
            WorldData.nearestAirport(loc.latitude, loc.longitude)?.let { (a, d) ->
                info.add("Proche : ${a.iata} ${a.shortCity} (${GeoMath.intFr(d)} km)")
            }
        }
        if (st.tracking) {
            val acc = loc?.takeIf { it.hasAccuracy() }?.let { " ±${it.accuracy.toInt()} m" } ?: ""
            info.add("GPS ${st.satsUsed}/${st.satsVisible} sat$acc")
        } else if (loc == null) {
            info.add("Astuce : démarre avant le décollage, le GPS marche en mode avion.")
        }
        tvInfo.text = info.joinToString("  ·  ")
    }

    // ------------------------------------------------------------- Choix du vol

    private fun applyRoute(fit: Boolean) {
        val dep = TrackingState.dep
        val dest = TrackingState.dest
        map.setRoute(dep, dest)
        if (dep != null && dest != null) {
            tvRoute.text = "${dep.iata} → ${dest.iata}"
            val km = GeoMath.distanceKm(dep.lat, dep.lon, dest.lat, dest.lon)
            tvRouteSub.text = "${dep.shortCity} → ${dest.shortCity} · ${GeoMath.intFr(km)} km à vol d'oiseau"
            if (fit && TrackingState.lastLocation == null) { map.setFollow(false); map.fitRoute() }
        } else {
            tvRoute.text = "Choisir le vol ✈"
            tvRouteSub.text = "Touchez ici pour indiquer départ et arrivée"
        }
    }

    private fun pickFlight() {
        if (!WorldData.loaded) { toast("Chargement des aéroports…"); return }
        chooseAirport("Aéroport de départ", allowNearest = true) { dep ->
            chooseAirport("Aéroport d'arrivée", allowNearest = false) { dest ->
                TrackingState.dep = dep
                TrackingState.dest = dest
                TrackingState.saveRoute(this)
                applyRoute(fit = true)
                updateDashboard()
            }
        }
    }

    private fun chooseAirport(title: String, allowNearest: Boolean, onPicked: (Airport) -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(8f), dp(16f), 0)
        }
        val input = EditText(this).apply {
            hint = "Ville, nom ou code (CDG, LFPG…)"
            setSingleLine()
        }
        val list = ListView(this)
        var results = WorldData.search("")
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, ArrayList(results.map { label(it) }))
        list.adapter = adapter
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                results = WorldData.search(s?.toString() ?: "")
                adapter.clear(); adapter.addAll(results.map { label(it) })
            }
        })
        box.addView(input)
        box.addView(list, LinearLayout.LayoutParams(-1, dp(360f)))

        val builder = AlertDialog.Builder(this).setTitle(title).setView(box).setNegativeButton("Annuler", null)
        val loc = TrackingState.lastLocation
        if (allowNearest && loc != null) {
            builder.setNeutralButton("Le plus proche") { _, _ ->
                WorldData.nearestAirport(loc.latitude, loc.longitude)?.let { onPicked(it.first) }
            }
        }
        val dialog = builder.create()
        list.setOnItemClickListener { _, _, pos, _ ->
            dialog.dismiss()
            results.getOrNull(pos)?.let(onPicked)
        }
        dialog.show()
    }

    private fun label(a: Airport) = "${a.iata}  ${a.shortCity} (${a.country})\n${a.name}"

    // ------------------------------------------------------------- Suivi GPS

    private fun toggleTracking() {
        if (TrackingState.tracking) {
            AlertDialog.Builder(this)
                .setTitle("Terminer le vol ?")
                .setMessage("Le suivi GPS s'arrête et la trace est enregistrée.")
                .setPositiveButton("Terminer") { _, _ -> TrackingService.stop(this) }
                .setNegativeButton("Continuer", null)
                .show()
            return
        }
        startTrackingChecked()
    }

    private fun startTrackingChecked() {
        val needed = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            needed += Manifest.permission.ACCESS_FINE_LOCATION
            needed += Manifest.permission.ACCESS_COARSE_LOCATION
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) needed += Manifest.permission.POST_NOTIFICATIONS
        if (needed.isNotEmpty()) {
            pendingStart = true
            requestPermissions(needed.toTypedArray(), 1)
            return
        }
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            AlertDialog.Builder(this)
                .setTitle("Localisation désactivée")
                .setMessage("Active la localisation (elle reste utilisable en mode avion).")
                .setPositiveButton("Réglages") { _, _ -> startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) }
                .setNegativeButton("Annuler", null)
                .show()
            return
        }
        TrackingService.start(this)
        map.setFollow(true)
        updateDashboard()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (!pendingStart) return
        pendingStart = false
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            startTrackingChecked()
        } else {
            AlertDialog.Builder(this)
                .setTitle("Position précise requise")
                .setMessage("Autorise la position « précise » pour Suivi Vol, sinon le GPS ne peut pas être utilisé.")
                .setPositiveButton("Paramètres de l'app") { _, _ ->
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.fromParts("package", packageName, null)))
                }
                .setNegativeButton("Annuler", null)
                .show()
        }
    }

    // ------------------------------------------------------------- Traces GPX

    private fun showTraces() {
        val files = GpxWriter.dir(this).listFiles { f -> f.name.endsWith(".gpx") }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()
        if (files.isEmpty()) { toast("Aucune trace pour l'instant"); return }
        val active = GpxWriter.activeFile(this)
        val labels = files.map { f ->
            val size = if (f.length() > 1_000_000) String.format(Locale.FRANCE, "%.1f Mo", f.length() / 1e6)
            else "${f.length() / 1000} ko"
            val tag = if (f.absolutePath == active?.absolutePath) " · en cours" else ""
            "${f.nameWithoutExtension.removePrefix("vol_").replace('_', ' ')}\n$size$tag"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Traces enregistrées")
            .setItems(labels) { _, i -> traceActions(files[i], files[i].absolutePath == active?.absolutePath) }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun traceActions(f: File, isActive: Boolean) {
        val b = AlertDialog.Builder(this)
            .setTitle(f.name)
            .setPositiveButton("Exporter / partager") { _, _ -> exportTrace(f) }
            .setNegativeButton("Fermer", null)
        if (!isActive) {
            b.setNeutralButton("Supprimer") { _, _ ->
                AlertDialog.Builder(this)
                    .setMessage("Supprimer définitivement cette trace ?")
                    .setPositiveButton("Supprimer") { _, _ -> f.delete(); toast("Trace supprimée") }
                    .setNegativeButton("Annuler", null)
                    .show()
            }
        }
        b.show()
    }

    /** Copie la trace dans Téléchargements/SuiviVol puis ouvre le menu de partage. */
    private fun exportTrace(f: File) {
        try {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/gpx+xml")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SuiviVol")
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("insertion impossible")
            contentResolver.openOutputStream(uri)?.use { it.write(GpxWriter.exportText(f).toByteArray()) }
            toast("Enregistré dans Téléchargements/SuiviVol")
            val share = Intent(Intent.ACTION_SEND).apply {
                type = "application/gpx+xml"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(share, "Partager la trace"))
        } catch (e: Exception) {
            toast("Export impossible : ${e.message}")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
