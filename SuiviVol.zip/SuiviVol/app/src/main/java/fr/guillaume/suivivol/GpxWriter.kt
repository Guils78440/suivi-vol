package fr.guillaume.suivivol

import android.content.Context
import android.location.Location
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Enregistre la trace GPS au format GPX, point par point (rien n'est perdu si l'app est tuée).
 * Une trace interrompue depuis moins de 6 h est reprise automatiquement au redémarrage du suivi.
 */
class GpxWriter private constructor(val file: File, append: Boolean) {

    private val writer = FileWriter(file, append)

    fun append(loc: Location) {
        val ele = GeoMath.altitudeM(loc)
        val sb = StringBuilder()
        sb.append(String.format(Locale.US, "      <trkpt lat=\"%.6f\" lon=\"%.6f\">", loc.latitude, loc.longitude))
        if (ele != null) sb.append(String.format(Locale.US, "<ele>%.1f</ele>", ele))
        sb.append("<time>").append(isoTime(loc.time)).append("</time></trkpt>\n")
        writer.write(sb.toString())
        writer.flush()
    }

    /** [finish] = true ferme définitivement la trace (fin du vol). */
    fun close(ctx: Context, finish: Boolean) {
        if (finish) {
            writer.write(FOOTER)
            prefs(ctx).edit().remove(KEY_ACTIVE).apply()
        }
        writer.close()
    }

    companion object {
        private const val KEY_ACTIVE = "active_gpx"
        private const val RESUME_WINDOW_MS = 6 * 3600 * 1000L
        private const val FOOTER = "    </trkseg>\n  </trk>\n</gpx>\n"
        private val POINT = Regex("lat=\"(-?[0-9.]+)\" lon=\"(-?[0-9.]+)\"")
        private val TIME = Regex("<time>([^<]+)</time>")

        private fun prefs(ctx: Context) = ctx.getSharedPreferences("suivi_vol", Context.MODE_PRIVATE)

        fun dir(ctx: Context): File = File(ctx.filesDir, "traces").apply { mkdirs() }

        fun activeFile(ctx: Context): File? =
            prefs(ctx).getString(KEY_ACTIVE, null)?.let { File(it) }?.takeIf { it.exists() }

        fun isFinished(f: File): Boolean = f.length() > 0 && f.readText().trimEnd().endsWith("</gpx>")

        /** Termine une trace restée ouverte (app tuée pendant le vol). */
        fun finishActive(ctx: Context) {
            activeFile(ctx)?.let { if (!isFinished(it)) it.appendText(FOOTER) }
            prefs(ctx).edit().remove(KEY_ACTIVE).apply()
        }

        /** Contenu prêt à exporter (ajoute la fermeture si la trace est en cours/interrompue). */
        fun exportText(f: File): String {
            val t = f.readText()
            return if (t.trimEnd().endsWith("</gpx>")) t else t + FOOTER
        }

        /**
         * Ouvre la trace active si elle est récente, sinon en crée une nouvelle.
         * Renvoie le writer + les points déjà enregistrés (pour réafficher la trace).
         */
        fun openOrResume(ctx: Context, dep: Airport?, dest: Airport?): Triple<GpxWriter, List<DoubleArray>, Long> {
            val active = activeFile(ctx)
            if (active != null && !isFinished(active)) {
                if (System.currentTimeMillis() - active.lastModified() < RESUME_WINDOW_MS) {
                    val text = active.readText()
                    val pts = POINT.findAll(text).map {
                        doubleArrayOf(it.groupValues[1].toDouble(), it.groupValues[2].toDouble())
                    }.toList()
                    val first = TIME.find(text)?.groupValues?.get(1)?.let { parseIso(it) } ?: 0L
                    val w = GpxWriter(active, true)
                    w.writer.write("    </trkseg>\n    <trkseg>\n")
                    w.writer.flush()
                    return Triple(w, pts, first)
                }
                // trace trop ancienne : on la termine proprement
                active.appendText(FOOTER)
            }
            val stamp = SimpleDateFormat("yyyy-MM-dd_HH'h'mm", Locale.FRANCE).format(Date())
            val route = if (dep != null && dest != null) "_${dep.iata}-${dest.iata}" else ""
            val f = File(dir(ctx), "vol_$stamp$route.gpx")
            val title = if (dep != null && dest != null) "${dep.shortCity} → ${dest.shortCity}" else "Vol $stamp"
            val w = GpxWriter(f, false)
            w.writer.write(
                "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                    "<gpx version=\"1.1\" creator=\"Suivi Vol\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n" +
                    "  <metadata><name>${xml(title)}</name><time>${isoTime(System.currentTimeMillis())}</time></metadata>\n" +
                    "  <trk>\n    <name>${xml(title)}</name>\n    <trkseg>\n"
            )
            w.writer.flush()
            prefs(ctx).edit().putString(KEY_ACTIVE, f.absolutePath).apply()
            return Triple(w, emptyList(), 0L)
        }

        private fun isoFormat() = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }

        fun isoTime(ms: Long): String = isoFormat().format(Date(ms))

        private fun parseIso(s: String): Long = try { isoFormat().parse(s)?.time ?: 0L } catch (e: Exception) { 0L }

        private fun xml(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    }
}
