package fr.guillaume.suivivol

import android.content.Context
import android.content.res.AssetManager
import android.os.Handler
import android.os.Looper
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.text.Normalizer
import kotlin.math.cos

/** Contour d'un pays, déjà projeté en Mercator normalisé. */
class Ring(val xs: FloatArray, val ys: FloatArray) {
    val minX = xs.min(); val maxX = xs.max()
    val minY = ys.min(); val maxY = ys.max()

    fun contains(x: Float, y: Float): Boolean {
        if (x < minX || x > maxX || y < minY || y > maxY) return false
        var inside = false
        var j = xs.size - 1
        for (i in xs.indices) {
            if ((ys[i] > y) != (ys[j] > y) &&
                x < (xs[j] - xs[i]) * (y - ys[i]) / (ys[j] - ys[i]) + xs[i]
            ) inside = !inside
            j = i
        }
        return inside
    }
}

class Country(val name: String, val rings: List<Ring>) {
    val minX = rings.minOf { it.minX }; val maxX = rings.maxOf { it.maxX }
    val minY = rings.minOf { it.minY }; val maxY = rings.maxOf { it.maxY }
}

class Airport(
    val iata: String,
    val icao: String,
    val name: String,
    val city: String,
    val country: String,
    val lat: Double,
    val lon: Double,
    val elevFt: Int,
    val large: Boolean,
) {
    val mx = GeoMath.mercX(lon).toFloat()
    val my = GeoMath.mercY(lat).toFloat()
    val shortCity: String get() = city.substringBefore(",").substringBefore(" (").ifBlank { name }
    internal val searchKey = WorldData.normalize("$iata $icao $name $city $country")
}

/** Carte du monde et aéroports embarqués dans l'APK (aucun réseau nécessaire). */
object WorldData {
    @Volatile var countries: List<Country> = emptyList(); private set
    @Volatile var airports: List<Airport> = emptyList(); private set
    @Volatile var loaded = false; private set

    private var loading = false
    private val pending = ArrayList<() -> Unit>()
    private val main = Handler(Looper.getMainLooper())

    /** Charge les données en arrière-plan, puis appelle [onReady] sur le thread principal. */
    fun load(context: Context, onReady: () -> Unit) {
        if (loaded) { onReady(); return }
        pending.add(onReady)
        if (loading) return
        loading = true
        val assets = context.applicationContext.assets
        Thread {
            val c = readWorld(assets)
            val a = readAirports(assets)
            main.post {
                countries = c
                airports = a
                loaded = true
                loading = false
                pending.forEach { it() }
                pending.clear()
            }
        }.start()
    }

    private fun readWorld(assets: AssetManager): List<Country> {
        val out = ArrayList<Country>()
        DataInputStream(BufferedInputStream(assets.open("world.bin"), 64 * 1024)).use { input ->
            val nCountries = input.readInt()
            repeat(nCountries) {
                val name = input.readUTF()
                val nRings = input.readInt()
                val rings = ArrayList<Ring>(nRings)
                repeat(nRings) {
                    val n = input.readInt()
                    val xs = FloatArray(n)
                    val ys = FloatArray(n)
                    for (i in 0 until n) {
                        val lat = input.readShort() / 100.0
                        val lon = input.readShort() / 100.0
                        xs[i] = GeoMath.mercX(lon).toFloat()
                        ys[i] = GeoMath.mercY(lat).toFloat()
                    }
                    rings.add(Ring(xs, ys))
                }
                if (rings.isNotEmpty()) out.add(Country(name, rings))
            }
        }
        return out
    }

    private fun readAirports(assets: AssetManager): List<Airport> {
        val out = ArrayList<Airport>(5000)
        assets.open("airports.tsv").bufferedReader(Charsets.UTF_8).useLines { lines ->
            lines.forEach { line ->
                val f = line.split('\t')
                if (f.size >= 9) {
                    out.add(
                        Airport(
                            f[0], f[1], f[2], f[3], f[4],
                            f[5].toDouble(), f[6].toDouble(), f[7].toIntOrNull() ?: 0, f[8] == "1"
                        )
                    )
                }
            }
        }
        return out
    }

    fun byIata(code: String?): Airport? =
        if (code.isNullOrBlank()) null else airports.firstOrNull { it.iata.equals(code, ignoreCase = true) }

    /** Nom du pays survolé, ou null au-dessus de la mer. */
    fun countryAt(lat: Double, lon: Double): String? {
        val x = GeoMath.mercX(lon).toFloat()
        val y = GeoMath.mercY(lat).toFloat()
        for (c in countries) {
            if (x < c.minX || x > c.maxX || y < c.minY || y > c.maxY) continue
            if (c.rings.any { it.contains(x, y) }) return c.name
        }
        return null
    }

    fun nearestAirport(lat: Double, lon: Double): Pair<Airport, Double>? {
        var best: Airport? = null
        var bestScore = Double.MAX_VALUE
        val k = cos(Math.toRadians(lat))
        for (a in airports) {
            var dLon = a.lon - lon
            if (dLon > 180) dLon -= 360
            if (dLon < -180) dLon += 360
            val dLat = a.lat - lat
            val score = dLat * dLat + (dLon * k) * (dLon * k)
            if (score < bestScore) { bestScore = score; best = a }
        }
        return best?.let { it to GeoMath.distanceKm(lat, lon, it.lat, it.lon) }
    }

    fun search(query: String, limit: Int = 80): List<Airport> {
        val q = normalize(query).trim()
        if (q.isEmpty()) return airports.filter { it.large }.sortedBy { it.city }.take(limit)
        val exact = airports.filter { it.iata.equals(q, true) || it.icao.equals(q, true) }
        val starts = airports.filter { it !in exact && normalize(it.city).startsWith(q) }
            .sortedByDescending { it.large }
        val contains = airports.filter { it !in exact && it !in starts && it.searchKey.contains(q) }
            .sortedByDescending { it.large }
        return (exact + starts + contains).take(limit)
    }

    private val ACCENTS = Regex("\\p{Mn}+")

    fun normalize(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(ACCENTS, "")
}
