package fr.guillaume.suivivol

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.GnssStatus
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/**
 * Service de premier plan : écoute la puce GPS seule (fonctionne en mode avion),
 * enregistre la trace et met à jour la notification, même écran éteint.
 */
class TrackingService : Service() {

    companion object {
        private const val ACTION_START = "fr.guillaume.suivivol.START"
        private const val ACTION_STOP = "fr.guillaume.suivivol.STOP"
        private const val CHANNEL = "suivi_vol"
        private const val NOTIF_ID = 42

        fun start(ctx: Context) {
            ctx.startForegroundService(Intent(ctx, TrackingService::class.java).setAction(ACTION_START))
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, TrackingService::class.java).setAction(ACTION_STOP))
        }
    }

    private lateinit var lm: LocationManager
    private var gpx: GpxWriter? = null
    private var listening = false
    private var lastNotif = 0L
    private val handler = Handler(Looper.getMainLooper())

    // Implémentation complète (pas de lambda) : Android 10 appelle encore onStatusChanged.
    private val locListener = object : LocationListener {
        override fun onLocationChanged(location: Location) = onFix(location)
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {
            updateNotification("Localisation désactivée — réactive-la dans les réglages")
        }
        @Deprecated("Requis pour Android 10")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    private val gnssCallback = object : GnssStatus.Callback() {
        override fun onSatelliteStatusChanged(status: GnssStatus) {
            var used = 0
            for (i in 0 until status.satelliteCount) if (status.usedInFix(i)) used++
            TrackingState.satsUsed = used
            TrackingState.satsVisible = status.satelliteCount
            if (TrackingState.lastLocation == null) {
                updateNotification("Recherche GPS… ${status.satelliteCount} satellites visibles", force = false)
            }
            TrackingState.notifyChanged()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Suivi du vol", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Position, altitude et vitesse pendant le vol"
                setShowBadge(false)
            }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            val hadWriter = gpx != null
            stopTracking(finish = true)
            if (!hadWriter) GpxWriter.finishActive(this)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            startForeground(
                NOTIF_ID,
                buildNotification("Recherche du signal GPS… (près du hublot, c'est plus rapide)"),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            )
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        startTracking()
        return START_NOT_STICKY
    }

    private fun startTracking() {
        if (listening) return
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return
        }
        val (writer, points, firstTime) = GpxWriter.openOrResume(this, TrackingState.dep, TrackingState.dest)
        gpx = writer
        TrackingState.restorePoints(points, firstTime)
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locListener, Looper.getMainLooper())
            lm.registerGnssStatusCallback(gnssCallback, handler)
        } catch (e: SecurityException) {
            stopSelf()
            return
        }
        listening = true
        TrackingState.tracking = true
        TrackingState.notifyChanged()
    }

    private fun stopTracking(finish: Boolean) {
        if (listening) {
            lm.removeUpdates(locListener)
            lm.unregisterGnssStatusCallback(gnssCallback)
            listening = false
        }
        gpx?.close(this, finish)
        gpx = null
        TrackingState.tracking = false
        TrackingState.satsUsed = 0
        TrackingState.satsVisible = 0
        TrackingState.notifyChanged()
    }

    private fun onFix(loc: Location) {
        TrackingState.addFix(loc)
        try { gpx?.append(loc) } catch (e: Exception) { /* stockage plein : on continue l'affichage */ }
        TrackingState.notifyChanged()
        updateNotification(summary(loc), force = false)
    }

    private fun summary(loc: Location): String {
        val parts = ArrayList<String>()
        GeoMath.altitudeM(loc)?.let { parts.add("${GeoMath.intFr(it * 3.28084)} ft") }
        val v = TrackingState.smoothedSpeed
        if (!v.isNaN()) parts.add("${GeoMath.intFr(v * 3.6)} km/h")
        TrackingState.remainingKm()?.let { parts.add("${GeoMath.intFr(it)} km restants") }
        return if (parts.isEmpty()) "Position GPS reçue" else parts.joinToString(" · ")
    }

    private fun updateNotification(text: String, force: Boolean = true) {
        val now = System.currentTimeMillis()
        if (!force && now - lastNotif < 5000) return
        lastNotif = now
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, TrackingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val dep = TrackingState.dep
        val dest = TrackingState.dest
        val title = if (dep != null && dest != null) "Vol ${dep.iata} → ${dest.iata}" else "Suivi du vol"
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_NAVIGATION)
            .addAction(Notification.Action.Builder(null, "Terminer le vol", stop).build())
            .build()
    }

    override fun onDestroy() {
        stopTracking(finish = false)
        super.onDestroy()
    }
}
