package fr.guillaume.suivivol

import android.content.Context
import android.location.Location
import java.util.concurrent.CopyOnWriteArrayList

/** État partagé entre le service GPS et l'écran (même processus, thread principal). */
object TrackingState {
    private const val PREFS = "suivi_vol"
    private const val MIN_DRAW_STEP_KM = 1.0
    private const val SPEED_ALPHA = 0.08

    var dep: Airport? = null
    var dest: Airport? = null

    var tracking = false
    var lastLocation: Location? = null
        private set
    var satsUsed = 0
    var satsVisible = 0

    /** Points de la trace pour l'affichage (décimés à ~1 km). */
    val trackLat = ArrayList<Double>()
    val trackLon = ArrayList<Double>()

    var distanceFlownKm = 0.0
        private set
    var firstFixTime = 0L
        private set
    /** Vitesse sol lissée en m/s (NaN tant qu'inconnue). */
    var smoothedSpeed = Double.NaN
        private set
    var bearing = Double.NaN
        private set

    private var prev: Location? = null
    private var restoredLast: DoubleArray? = null
    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    fun notifyChanged() { listeners.forEach { it() } }

    fun loadRoute(ctx: Context) {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        dep = WorldData.byIata(p.getString("dep", null))
        dest = WorldData.byIata(p.getString("dest", null))
    }

    fun saveRoute(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("dep", dep?.iata)
            .putString("dest", dest?.iata)
            .apply()
    }

    fun resetTrack() {
        trackLat.clear(); trackLon.clear()
        distanceFlownKm = 0.0
        firstFixTime = 0L
        smoothedSpeed = Double.NaN
        bearing = Double.NaN
        prev = null
        restoredLast = null
        lastLocation = null
    }

    /** Recharge une trace existante (reprise après fermeture de l'app). */
    fun restorePoints(points: List<DoubleArray>, firstTime: Long) {
        resetTrack()
        var last: DoubleArray? = null
        for (p in points) {
            last?.let { distanceFlownKm += GeoMath.distanceKm(it[0], it[1], p[0], p[1]) }
            addDrawPoint(p[0], p[1])
            last = p
        }
        firstFixTime = firstTime
        restoredLast = last
    }

    fun addFix(loc: Location) {
        val p = prev
        if (firstFixTime == 0L) firstFixTime = loc.time
        var instSpeed = if (loc.hasSpeed()) loc.speed.toDouble() else Double.NaN
        restoredLast?.let {
            // reprise : on compte la distance parcourue pendant l'interruption
            distanceFlownKm += GeoMath.distanceKm(it[0], it[1], loc.latitude, loc.longitude)
            restoredLast = null
        }
        if (p != null) {
            val d = GeoMath.distanceKm(p.latitude, p.longitude, loc.latitude, loc.longitude)
            val dt = (loc.time - p.time) / 1000.0
            // Filtre anti-sauts : on ignore les déplacements irréalistes (> 1 300 km/h)
            if (dt > 0 && d / dt * 3600 < 1300) {
                distanceFlownKm += d
                if (instSpeed.isNaN()) instSpeed = d * 1000 / dt
                if (d > 0.05) bearing = GeoMath.bearingDeg(p.latitude, p.longitude, loc.latitude, loc.longitude)
            }
        }
        if (loc.hasBearing() && loc.hasSpeed() && loc.speed > 3f) bearing = loc.bearing.toDouble()
        if (!instSpeed.isNaN()) {
            smoothedSpeed = if (smoothedSpeed.isNaN()) instSpeed
            else smoothedSpeed + SPEED_ALPHA * (instSpeed - smoothedSpeed)
        }
        addDrawPoint(loc.latitude, loc.longitude)
        prev = loc
        lastLocation = loc
    }

    private fun addDrawPoint(lat: Double, lon: Double) {
        val n = trackLat.size
        if (n == 0 || GeoMath.distanceKm(trackLat[n - 1], trackLon[n - 1], lat, lon) >= MIN_DRAW_STEP_KM) {
            trackLat.add(lat); trackLon.add(lon)
        } else if (n >= 2) {
            // on remplace le dernier point pour que la trace colle à la position actuelle
            trackLat[n - 1] = lat; trackLon[n - 1] = lon
        } else {
            trackLat.add(lat); trackLon.add(lon)
        }
    }

    fun routeKm(): Double? {
        val a = dep ?: return null
        val b = dest ?: return null
        return GeoMath.distanceKm(a.lat, a.lon, b.lat, b.lon)
    }

    fun remainingKm(): Double? {
        val l = lastLocation ?: return null
        val b = dest ?: return null
        return GeoMath.distanceKm(l.latitude, l.longitude, b.lat, b.lon)
    }

    /** Durée restante estimée (ms) à vitesse sol actuelle, si l'avion est en vol. */
    fun remainingMillis(): Long? {
        val rem = remainingKm() ?: return null
        val v = smoothedSpeed
        if (v.isNaN() || v < 30.0) return null // < 108 km/h : au sol / roulage
        return (rem * 1000.0 / v * 1000.0).toLong()
    }

    /** Avancement 0..1 sur la route départ → arrivée. */
    fun progress(): Double? {
        val total = routeKm() ?: return null
        val rem = remainingKm() ?: return null
        if (total < 1) return null
        return (1.0 - rem / total).coerceIn(0.0, 1.0)
    }
}
