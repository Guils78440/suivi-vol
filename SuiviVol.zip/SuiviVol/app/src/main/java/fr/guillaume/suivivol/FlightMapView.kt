package fr.guillaume.suivivol

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * Carte du monde vectorielle dessinée à la main (aucune tuile à télécharger).
 * Projection Mercator, déplacement au doigt, zoom à deux doigts / double-tap.
 */
class FlightMapView(context: Context) : View(context) {

    private val density = resources.displayMetrics.density

    // Vue : centre en Mercator normalisé + niveau de zoom (log2)
    private var cx = 0.5
    private var cy = 0.42
    private var zoom = 0.6
    private val minZoom = 0.0
    private val maxZoom = 11.0

    var follow = true
        private set
    var onFollowChanged: ((Boolean) -> Unit)? = null

    private var route: List<DoubleArray> = emptyList() // [mercX, mercY] déroulés
    private var pendingFit = false

    // ---- Style néon sombre ----
    private val cOcean = Color.parseColor("#06101C")
    private val pLand = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#122438"); style = Paint.Style.FILL }
    private val pBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#2E5578"); style = Paint.Style.STROKE; strokeWidth = 0.8f * density
    }
    private val pGrid = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0F2236"); style = Paint.Style.STROKE; strokeWidth = 1f
    }
    private val pRoute = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF4FD8"); style = Paint.Style.STROKE; strokeWidth = 2f * density
        pathEffect = DashPathEffect(floatArrayOf(8f * density, 6f * density), 0f)
    }
    private val pTrackGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#4000E5FF"); style = Paint.Style.STROKE; strokeWidth = 8f * density
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val pTrack = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E5FF"); style = Paint.Style.STROKE; strokeWidth = 3f * density
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val pApt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#5F86A8") }
    private val pAptMain = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FF4FD8") }
    private val pText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#C9DCEE"); textSize = 11f * density
    }
    private val pTextHalo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = cOcean; textSize = 11f * density; style = Paint.Style.STROKE; strokeWidth = 3f * density
    }
    private val pTextMain = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 13f * density; isFakeBoldText = true
    }
    private val pPlaneGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#5500E5FF") }
    private val pPlane = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FFE14D") }
    private val pPlaneEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#06101C"); style = Paint.Style.STROKE; strokeWidth = 1.2f * density
    }

    private val path = Path()
    private val planePath = Path().apply {
        val pts = floatArrayOf(
            0f, -12f, 1.5f, -10f, 1.5f, -3f, 11f, 3f, 11f, 5f, 1.5f, 2f, 1.5f, 8f, 4f, 10f, 4f, 11.5f,
            0f, 10.5f, -4f, 11.5f, -4f, 10f, -1.5f, 8f, -1.5f, 2f, -11f, 5f, -11f, 3f, -1.5f, -3f, -1.5f, -10f
        )
        val s = 1.7f * density
        moveTo(pts[0] * s, pts[1] * s)
        var i = 2
        while (i < pts.size) { lineTo(pts[i] * s, pts[i + 1] * s); i += 2 }
        close()
    }

    // ---- Gestes ----
    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            zoomAround(ln(d.scaleFactor.toDouble()) / ln(2.0), d.focusX, d.focusY)
            return true
        }
    })

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            val wp = worldPx()
            cx += dx / wp
            cy = (cy + dy / wp).coerceIn(0.0, 1.0)
            setFollow(false)
            invalidate()
            return true
        }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            zoomAround(1.0, e.x, e.y)
            return true
        }
    })

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        if (!scaleDetector.isInProgress) gestureDetector.onTouchEvent(event)
        return true
    }

    private fun zoomAround(dz: Double, fx: Float, fy: Float) {
        val before = worldPx()
        val mx = cx + (fx - width / 2.0) / before
        val my = cy + (fy - height / 2.0) / before
        zoom = (zoom + dz).coerceIn(minZoom, maxZoom)
        val after = worldPx()
        if (!follow) {
            cx = mx - (fx - width / 2.0) / after
            cy = (my - (fy - height / 2.0) / after).coerceIn(0.0, 1.0)
        }
        invalidate()
    }

    private fun worldPx(): Double = 256.0 * 2.0.pow(zoom) * density

    fun setFollow(f: Boolean) {
        if (follow == f) return
        follow = f
        onFollowChanged?.invoke(f)
        if (f) refresh()
    }

    // ---- API ----
    fun setRoute(dep: Airport?, dest: Airport?) {
        route = if (dep != null && dest != null) {
            GeoMath.greatCircle(dep.lat, dep.lon, dest.lat, dest.lon)
                .map { doubleArrayOf(GeoMath.mercX(it[1]), GeoMath.mercY(it[0])) }
        } else emptyList()
        invalidate()
    }

    /** Cadre la vue sur toute la route. */
    fun fitRoute() {
        if (width == 0 || height == 0) { pendingFit = true; return }
        val pts = route
        if (pts.isEmpty()) return
        val minX = pts.minOf { it[0] }; val maxX = pts.maxOf { it[0] }
        val minY = pts.minOf { it[1] }; val maxY = pts.maxOf { it[1] }
        cx = (minX + maxX) / 2
        cy = (minY + maxY) / 2
        val spanX = max(maxX - minX, 0.002)
        val spanY = max(maxY - minY, 0.002)
        val scale = min(width / (spanX * 1.35), height / (spanY * 1.5))
        zoom = (ln(scale / (256.0 * density)) / ln(2.0)).coerceIn(minZoom, maxZoom)
        invalidate()
    }

    /** À appeler à chaque nouvelle position. */
    fun refresh() {
        val loc = TrackingState.lastLocation
        if (follow && loc != null) {
            val tx = GeoMath.mercX(loc.longitude)
            // garder cx proche de la copie du monde actuellement affichée
            cx = tx + Math.round(cx - tx)
            cy = GeoMath.mercY(loc.latitude)
            if (zoom < 4.0 && TrackingState.tracking && route.isEmpty()) zoom = 4.0
        }
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (pendingFit) { pendingFit = false; fitRoute() }
    }

    // ---- Dessin ----
    private fun sx(mx: Double, wp: Double): Float = ((mx - cx) * wp + width / 2.0).toFloat()
    private fun sy(my: Double, wp: Double): Float = ((my - cy) * wp + height / 2.0).toFloat()

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(cOcean)
        val wp = worldPx()
        val left = cx - width / 2.0 / wp
        val right = cx + width / 2.0 / wp
        val top = cy - height / 2.0 / wp
        val bottom = cy + height / 2.0 / wp

        drawGrid(canvas, wp, left, right, top, bottom)

        // Copies du monde pour un défilement horizontal infini
        for (k in floor(left).toInt()..floor(right).toInt()) {
            drawCountries(canvas, wp, k.toDouble(), left, right, top, bottom)
        }
        if (zoom >= 3.0) {
            for (k in floor(left).toInt()..floor(right).toInt()) drawAirports(canvas, wp, k.toDouble(), left, right, top, bottom)
        }
        for (k in floor(left).toInt() - 1..floor(right).toInt() + 1) {
            drawRoute(canvas, wp, k.toDouble())
            drawTrack(canvas, wp, k.toDouble())
        }
        drawEndpoints(canvas, wp)
        drawPlane(canvas, wp)
    }

    private fun drawGrid(canvas: Canvas, wp: Double, left: Double, right: Double, top: Double, bottom: Double) {
        val step = if (zoom >= 4) 5 else if (zoom >= 2) 10 else 30
        var lat = -80
        while (lat <= 80) {
            val y = sy(GeoMath.mercY(lat.toDouble()), wp)
            if (y in 0f..height.toFloat()) canvas.drawLine(0f, y, width.toFloat(), y, pGrid)
            lat += step
        }
        val firstLon = floor((left * 360 - 180) / step).toInt() * step
        var lon = firstLon
        while (GeoMath.mercX(lon.toDouble()) <= right) {
            val x = sx(GeoMath.mercX(lon.toDouble()), wp)
            canvas.drawLine(x, sy(GeoMath.mercY(85.0), wp).coerceAtLeast(0f), x, sy(GeoMath.mercY(-85.0), wp).coerceAtMost(height.toFloat()), pGrid)
            lon += step
        }
    }

    private fun drawCountries(canvas: Canvas, wp: Double, off: Double, l: Double, r: Double, t: Double, b: Double) {
        val minPx = 1.2f
        for (c in WorldData.countries) {
            if (c.maxX + off < l || c.minX + off > r || c.maxY < t || c.minY > b) continue
            path.rewind()
            for (ring in c.rings) {
                if (ring.maxX + off < l || ring.minX + off > r || ring.maxY < t || ring.minY > b) continue
                val xs = ring.xs; val ys = ring.ys
                var lx = sx(xs[0] + off, wp); var ly = sy(ys[0].toDouble(), wp)
                path.moveTo(lx, ly)
                val last = xs.size - 1
                for (i in 1..last) {
                    val x = sx(xs[i] + off, wp); val y = sy(ys[i].toDouble(), wp)
                    if (i == last || abs(x - lx) >= minPx || abs(y - ly) >= minPx) {
                        path.lineTo(x, y); lx = x; ly = y
                    }
                }
                path.close()
            }
            canvas.drawPath(path, pLand)
            canvas.drawPath(path, pBorder)
        }
    }

    private fun drawAirports(canvas: Canvas, wp: Double, off: Double, l: Double, r: Double, t: Double, b: Double) {
        val r0 = 2.2f * density
        val showSmall = zoom >= 5.0
        val showLabels = zoom >= 5.5
        for (a in WorldData.airports) {
            if (!a.large && !showSmall) continue
            val mx = a.mx + off
            if (mx < l || mx > r || a.my < t || a.my > b) continue
            val x = sx(mx, wp); val y = sy(a.my.toDouble(), wp)
            canvas.drawCircle(x, y, if (a.large) r0 * 1.3f else r0, pApt)
            if (showLabels || (a.large && zoom >= 4.5)) {
                canvas.drawText(a.iata, x + 5 * density, y + 4 * density, pTextHalo)
                canvas.drawText(a.iata, x + 5 * density, y + 4 * density, pText)
            }
        }
    }

    private fun drawRoute(canvas: Canvas, wp: Double, off: Double) {
        if (route.size < 2) return
        path.rewind()
        path.moveTo(sx(route[0][0] + off, wp), sy(route[0][1], wp))
        for (i in 1 until route.size) path.lineTo(sx(route[i][0] + off, wp), sy(route[i][1], wp))
        canvas.drawPath(path, pRoute)
    }

    private fun drawTrack(canvas: Canvas, wp: Double, off: Double) {
        val lats = TrackingState.trackLat
        val lons = TrackingState.trackLon
        val loc = TrackingState.lastLocation
        if (lats.isEmpty()) return
        path.rewind()
        var prevLon = lons[0]
        path.moveTo(sx(GeoMath.mercX(prevLon) + off, wp), sy(GeoMath.mercY(lats[0]), wp))
        val n = lats.size
        for (i in 1..n) {
            val lat: Double
            var lon: Double
            if (i < n) { lat = lats[i]; lon = lons[i] } else if (loc != null) { lat = loc.latitude; lon = loc.longitude } else break
            while (lon - prevLon > 180) lon -= 360
            while (lon - prevLon < -180) lon += 360
            path.lineTo(sx(GeoMath.mercX(lon) + off, wp), sy(GeoMath.mercY(lat), wp))
            prevLon = lon
        }
        canvas.drawPath(path, pTrackGlow)
        canvas.drawPath(path, pTrack)
    }

    private fun drawEndpoints(canvas: Canvas, wp: Double) {
        val pts = listOfNotNull(TrackingState.dep, TrackingState.dest)
        for (a in pts) {
            val off = Math.round(cx - a.mx).toDouble()
            val x = sx(a.mx + off, wp); val y = sy(a.my.toDouble(), wp)
            canvas.drawCircle(x, y, 5f * density, pAptMain)
            canvas.drawCircle(x, y, 2f * density, pPlane)
            val label = "${a.iata} ${a.shortCity}"
            pTextHalo.textSize = pTextMain.textSize
            canvas.drawText(label, x + 8 * density, y - 6 * density, pTextHalo)
            canvas.drawText(label, x + 8 * density, y - 6 * density, pTextMain)
            pTextHalo.textSize = pText.textSize
        }
    }

    private fun drawPlane(canvas: Canvas, wp: Double) {
        val loc = TrackingState.lastLocation ?: return
        val mx = GeoMath.mercX(loc.longitude)
        val off = Math.round(cx - mx).toDouble()
        val x = sx(mx + off, wp); val y = sy(GeoMath.mercY(loc.latitude), wp)
        canvas.drawCircle(x, y, 22f * density, pPlaneGlow)
        canvas.save()
        canvas.translate(x, y)
        val b = TrackingState.bearing
        if (!b.isNaN()) canvas.rotate(b.toFloat())
        canvas.drawPath(planePath, pPlane)
        canvas.drawPath(planePath, pPlaneEdge)
        canvas.restore()
    }
}
