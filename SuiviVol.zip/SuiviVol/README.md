# Suivi Vol ✈

Application Android pour suivre sa position en avion **en mode avion** : la puce GPS du téléphone
reçoit les satellites sans réseau, et la carte du monde + 4 568 aéroports sont embarqués dans l'APK.

## Fonctions

- Carte vectorielle du monde hors-ligne (frontières, graticule, aéroports), zoom et déplacement au doigt
- Route orthodromique départ → arrivée (pointillés magenta) et trace réellement volée (cyan)
- Altitude (m, ft, niveau de vol), vitesse sol (km/h, nœuds), cap
- Distance restante, heure d'arrivée estimée, distance parcourue, % du trajet
- Pays survolé et aéroport le plus proche
- Suivi en arrière-plan écran éteint (notification permanente avec bouton « Terminer le vol »)
- Trace GPX enregistrée point par point, reprise automatique si l'app est fermée en vol,
  export dans Téléchargements/SuiviVol + partage

## Compiler l'APK

### Option A — GitHub Actions (rien à installer)

1. Crée un dépôt GitHub vide (privé si tu veux), par ex. `suivi-vol`.
2. Envoie tout le contenu de ce dossier à la racine du dépôt (y compris `.github/`, `gradlew`, `app/debug.keystore`).
3. Onglet **Actions** : le workflow « Build APK » se lance tout seul à chaque push (≈ 4 min).
4. Onglet **Releases** → « Dernière version » → télécharge `SuiviVol.apk` depuis le téléphone.
5. Ouvre l'APK et autorise l'installation depuis ton navigateur / gestionnaire de fichiers.

Les mises à jour s'installent par-dessus l'ancienne version (clé de signature fixe incluse).

### Option B — Android Studio

1. Fichier → Ouvrir → ce dossier. Laisse la synchronisation Gradle se terminer.
2. Branche le téléphone (débogage USB activé) → ▶ Run.

## Utilisation en vol

1. **Avant d'embarquer** : bouton **Vol** → choisis départ puis arrivée (recherche par ville ou code CDG/LFPG).
2. Lance **▶ Démarrer** avant de passer en mode avion et accepte : position *précise* + notifications.
3. Mode avion : la localisation reste active. Le premier signal peut prendre 2 à 10 min ; pose le téléphone
   **contre le hublot** (le fuselage métallique bloque le signal au milieu de l'avion).
4. Écran éteint, le suivi continue. **■ Terminer le vol** à l'arrivée, puis **Traces** pour exporter le GPX.

Remarques :
- Sur Android 13 et moins, l'altitude affichée est ellipsoïdale (écart de quelques dizaines de mètres) ;
  Android 14+ fournit l'altitude au-dessus du niveau de la mer.
- L'heure d'arrivée est donnée à l'heure du téléphone (fuseau de départ tant qu'il n'a pas changé).
- Si le suivi s'arrête (batterie, app tuée), relance **Démarrer** : la trace des 6 dernières heures est reprise.
- Certains fabricants (Xiaomi, Huawei, Honor…) tuent les apps en arrière-plan : mets « Suivi Vol » en
  « Pas de restriction » dans Paramètres → Batterie.

## Structure

```
app/src/main/
├── AndroidManifest.xml
├── assets/world.bin          carte du monde (Natural Earth, simplifiée, noms FR)
├── assets/airports.tsv       aéroports avec code IATA (OurAirports)
└── java/fr/guillaume/suivivol/
    ├── MainActivity.kt       écran : carte, tableau de bord, choix du vol, traces
    ├── FlightMapView.kt      rendu de la carte (Canvas, Mercator)
    ├── TrackingService.kt    service GPS de premier plan + notification
    ├── TrackingState.kt      état partagé, vitesse lissée, distances, ETA
    ├── GpxWriter.kt          enregistrement / reprise / export GPX
    ├── WorldData.kt          chargement carte + aéroports, pays survolé, recherche
    └── GeoMath.kt            distances, caps, orthodromie, projection
```

Aucune dépendance externe (ni AndroidX, ni Google Play Services) : Kotlin + API Android uniquement.
minSdk 29 (Android 10), targetSdk 35.

Données : © Natural Earth (domaine public), © OurAirports (domaine public).
